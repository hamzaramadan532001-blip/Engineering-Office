export type AvailableTools = ["widgets"];
