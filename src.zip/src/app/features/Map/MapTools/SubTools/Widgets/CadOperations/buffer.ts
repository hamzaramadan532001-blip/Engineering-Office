"use client";

import * as geodesicBufferOperator from "@arcgis/core/geometry/operators/geodesicBufferOperator.js";
import type EsriPolygon from "@arcgis/core/geometry/Polygon";
import SpatialReference from "@arcgis/core/geometry/SpatialReference";
import {
  fromEsriGeometry,
  toEsriGeometry,
  type GeoJSONFeatureCollection,
} from "../CadUploadTool/geometry";

export async function buildBufferCollection(
  collection: GeoJSONFeatureCollection,
  distanceMeters: number,
): Promise<GeoJSONFeatureCollection | null> {
  if (!geodesicBufferOperator.isLoaded()) await geodesicBufferOperator.load();

  const wgs84 = new SpatialReference({ wkid: 4326 });

  const geometries = collection.features
    .map((feature) => (feature.geometry ? toEsriGeometry(feature.geometry, wgs84) : null))
    .filter((geometry): geometry is NonNullable<typeof geometry> => geometry !== null);

  if (geometries.length === 0) return null;

  const buffered = geodesicBufferOperator.executeMany(
    geometries,
    geometries.map(() => distanceMeters),
    { unit: "meters", union: true },
  ) as Array<EsriPolygon | null> | null;

  const polygons = (buffered ?? []).filter((polygon): polygon is EsriPolygon => Boolean(polygon));
  if (polygons.length === 0) return null;

  return {
    type: "FeatureCollection",
    features: polygons.map((polygon, index) => ({
      type: "Feature" as const,
      id: index,
      properties: { bufferDistance: distanceMeters },
      geometry: fromEsriGeometry(polygon),
    })),
  };
}
