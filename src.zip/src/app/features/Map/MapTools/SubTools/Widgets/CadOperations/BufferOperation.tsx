"use client";

import { Button, Group, Stack, Text } from "@makkah-municipality-gis/ui";
import Color from "@arcgis/core/Color";
import SimpleRenderer from "@arcgis/core/renderers/SimpleRenderer";
import SimpleFillSymbol from "@arcgis/core/symbols/SimpleFillSymbol";
import { useState } from "react";
import { resolveToken } from "@/lib/designTokens";
import { hexToRgba } from "../CadUploadTool/geometry";
import type { CadDrawing } from "../CadUploadTool/store";
import { buildBufferCollection } from "./buffer";
import styles from "./CadOperations.module.scss";
import {
  BUFFER_COLOR_TOKEN,
  BUFFER_FILL_OPACITY,
  COPY,
  DEFAULT_BUFFER_DISTANCE,
  MAX_BUFFER_DISTANCE,
  MIN_BUFFER_DISTANCE,
} from "./constants";
import { useOperationLayer } from "./useOperationLayer";

export default function BufferOperation({ drawing }: { drawing: CadDrawing }) {
  const [distance, setDistance] = useState(DEFAULT_BUFFER_DISTANCE);
  const [color, setColor] = useState(() => resolveToken(BUFFER_COLOR_TOKEN, "#12B76A"));

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const { applyLayer, removeLayer, hasOutput } = useOperationLayer("buffer", drawing.drawId);

  const handleApply = async () => {
    setBusy(true);
    setError("");
    setMessage("");

    try {
      const collection = await buildBufferCollection(drawing.geoJSON, distance);
      if (!collection) throw new Error(COPY.buffer.failed);

      const base = hexToRgba(color, 100);

      await applyLayer(
        collection,
        new SimpleRenderer({
          symbol: new SimpleFillSymbol({
            color: new Color([base.r, base.g, base.b, BUFFER_FILL_OPACITY]),
            style: "solid",
            outline: { color, width: 1, style: "dash" },
          }),
        }),
      );

      setMessage(COPY.buffer.done(distance));
    } catch (err) {
      console.error("[CAD ops] buffer failed:", err);
      setError(err instanceof Error ? err.message : COPY.errors.generic);
    } finally {
      setBusy(false);
    }
  };

  const handleRemove = () => {
    removeLayer();
    setMessage("");
    setError("");
  };

  return (
    <Stack gap={10}>
      <Text size="xs" c="dimmed">
        {COPY.buffer.summary}
      </Text>

      <Group gap={8} wrap="nowrap" align="flex-end">
        <label className={styles.numberField}>
          <span>{COPY.buffer.distance}</span>
          <input
            type="number"
            min={MIN_BUFFER_DISTANCE}
            max={MAX_BUFFER_DISTANCE}
            step={10}
            value={distance}
            onChange={(e) => setDistance(Number(e.target.value) || DEFAULT_BUFFER_DISTANCE)}
            disabled={busy}
          />
        </label>

        <label className={styles.colorField}>
          <span>{COPY.buffer.color}</span>
          <input
            type="color"
            value={color}
            onChange={(e) => setColor(e.target.value)}
            disabled={busy}
          />
        </label>
      </Group>

      {message && <div className={styles.message}>{message}</div>}
      {error && <div className={styles.error}>{error}</div>}

      <Group gap={8} wrap="nowrap" className={styles.operationActions}>
        {hasOutput && (
          <Button variant="default" size="compact-sm" onClick={handleRemove} disabled={busy}>
            {COPY.remove}
          </Button>
        )}
        <Button size="compact-sm" onClick={handleApply} loading={busy}>
          {busy ? COPY.applying : COPY.apply}
        </Button>
      </Group>
    </Stack>
  );
}
