"use client";

import { Text } from "@makkah-municipality-gis/ui";
import { useState, useSyncExternalStore, type ComponentType } from "react";
import { HiChevronDown, HiOutlineSquares2X2 } from "react-icons/hi2";
import { cadDrawingStore, type CadDrawing } from "../CadUploadTool/store";
import BufferOperation from "./BufferOperation";
import styles from "./CadOperations.module.scss";
import { COPY } from "./constants";
import IntersectOperation from "./IntersectOperation";


type Operation = {
  id: string;
  title: string;
  Component: ComponentType<{ drawing: CadDrawing }>;
};

const OPERATIONS: Operation[] = [
  { id: "buffer", title: COPY.buffer.title, Component: BufferOperation },
  { id: "intersect", title: COPY.intersect.title, Component: IntersectOperation },
];

export default function CadOperations() {
  const drawing = useSyncExternalStore(
    cadDrawingStore.subscribe,
    cadDrawingStore.getSnapshot,
    cadDrawingStore.getServerSnapshot,
  );

  const [panelOpen, setPanelOpen] = useState(false);
  const [openOperationId, setOpenOperationId] = useState<string | null>(OPERATIONS[0]?.id ?? null);

  // The whole rail only exists once something is actually drawn — no point
  // offering operations with nothing to operate on.
  if (!drawing) return null;

  return (
    <div className={styles.rail}>
      <button
        type="button"
        className={styles.railToggle}
        aria-expanded={panelOpen}
        aria-label={COPY.toggleAria}
        onClick={() => setPanelOpen((open) => !open)}
      >
        <HiOutlineSquares2X2 size={18} />
        <span className={styles.railToggleLabel}>{COPY.title}</span>
        <HiChevronDown
          size={16}
          className={`${styles.railChevron} ${panelOpen ? styles.railChevronOpen : ""}`}
        />
      </button>

      <div className={styles.panel} hidden={!panelOpen}>
        <div className={styles.activeFile}>
          <Text size="xs" c="dimmed">
            {COPY.activeFilePrefix}
          </Text>
          <Text size="xs" fw={600} className={styles.activeFileName}>
            {drawing.fileName}
          </Text>
        </div>

        {OPERATIONS.map(({ id, title, Component }) => {
          const expanded = openOperationId === id;

          return (
            <section key={id} className={styles.operation}>
              <button
                type="button"
                className={styles.operationHeader}
                aria-expanded={expanded}
                onClick={() => setOpenOperationId(expanded ? null : id)}
              >
                <span>{title}</span>
                <HiChevronDown
                  size={14}
                  className={`${styles.operationChevron} ${
                    expanded ? styles.operationChevronOpen : ""
                  }`}
                />
              </button>

              <div className={styles.operationBody} hidden={!expanded}>
                <Component drawing={drawing} />
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}